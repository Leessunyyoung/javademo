package java023_jdbc.part01;

public class Java222_jdbc {
	public static void main(String[] args) {
	
	JdbcTest jTest = new JdbcTest();
	jTest.process();
	}
}
